#include "mymainframe.h"

MyMainFrame::MyMainFrame(const TGWindow *p,UInt_t w,UInt_t h)
{
    // Create the main frame
    fMain = new TGMainFrame(p,w,h);

    twStatus_label = new TGTextView(fMain, 400, 400);
    fMain->AddFrame(twStatus_label);

    // Set a name to the main frame
    fMain->SetWindowName("Test GUI");

    // Map all subwindows of main frame
    fMain->MapSubwindows();

    // Initialize the layout algorithm
    fMain->Resize(fMain->GetDefaultSize());

    // Map main frame
    fMain->MapWindow();

}

MyMainFrame::~MyMainFrame()
{
   // Clean up used widgets: frames, buttons, layout hints
   fMain->Cleanup();
   delete fMain;
}

void MyMainFrame::RunThread()
{
    //Threads
    slave_thread = new TThread("slave_thread", (void(*) (void *))ReadoutLoop, (void*) this);
    slave_thread->Run();
}

void *MyMainFrame::ReadoutLoop(void *aPtr)
{

    MyMainFrame *p = (MyMainFrame*)aPtr;

    while(1)
    {
        TThread::Lock();
        ostringstream osstr;
        osstr << p->twStatus_label->ReturnLineCount();
        p->twStatus_label->AddLine( osstr.str().c_str() );
        p->twStatus_label->ShowBottom();
        TThread::UnLock();

        gSystem->Sleep(100);
    }
}

#pragma link C++ class Worker;
#pragma link C++ class MyMainFrame;
